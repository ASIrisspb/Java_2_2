package ASIris;

import javafx.util.Pair;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        String[][] strings = new String[][]
                {   {"1", "2", "3", "4"},
                    {"1", "2", "3", "4"},
                    {"1", "2о", "3", "4"},
                    {"1", "2", "3", "4"}   };
        System.out.println("Сумма элементов массива: " + myArrayMethod(strings));
    }

    public static int myArrayMethod(String[][] myArray) {
        //проверяем размерность переданного массива
        try {
            if (myArray.length != 4) {
                throw new MyArraySizeException();
            } else {
                for (String[] strings : myArray) {
                    if (strings.length != 4) {
                        throw new MyArraySizeException();
                    }
                }
            }
        //если размерность неправильная, то выводим сообщение
        } catch (MyArraySizeException e) {
            System.out.println("Передан массив неправильного размера!");
        }
        //переменная для хранения суммы
        int sum = 0;
        //переменная для хранения результата перевода из строки в число
        int numberOfSting = 0;
        //проходим по всем элементам массива
        for (int i = 0; i < myArray.length; i++) {
            for (int j = 0; j < myArray[i].length; j++) {
                //обнуляем, чтобы не получилось ложной суммы
                numberOfSting = 0;
                try {
                    numberOfSting = Integer.parseInt(myArray[i][j]);
                } catch (NumberFormatException e) {
                    Pair<Integer, Integer> indexOfMistake = new Pair<>(i,j);
                    MyArrayDataException.indexOfMistake.add(indexOfMistake);
                }
                sum += numberOfSting;
            }
        }
        if (MyArrayDataException.indexOfMistake.size() != 0) {
            System.out.println("В массиве обнаружены ошибки (вместо чисел стоят недопустимые символы) " +
                    "- их индексы приведены ниже:");
            System.out.println(MyArrayDataException.indexOfMistake);
        }
    return sum;
    }
}
//класс обнаружения ошибка размерности массива
class MyArraySizeException extends Exception {

}
//класс обнаружения и фиксации ошибки "нечислового" элемента массива
class MyArrayDataException extends Exception {
    static ArrayList<Pair<Integer,Integer>> indexOfMistake = new ArrayList<>();
}


